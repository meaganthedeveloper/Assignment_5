//
//  ConverterLogic.swift
//  CurrencyConverter
//
//  Created by Meagan Williams on 2/18/23.
//

import Foundation

struct ConverterLogic{
    //euro 0.93497
    mutating func convertToEuro(_ amount: Double) -> Double {
        let euroRate : Double = 0.93297
        let euro = amount * euroRate
        return round(100.0 * euro) / 100.0
    }
    
    mutating func convertToYen(_ amount: Double) -> Double {
        //Yen Japan 134.14800
        let yenRate : Double = 134.14800
        let yen = amount * yenRate
        return round(100.0 * yen) / 100.0
    }
    
    mutating func convertToPeso(_ amount: Double) -> Double {
        //Peso Mexico 18.38423
        let pesoRate : Double = 18.38423
        let peso = amount * pesoRate
        return round(100.0 * peso) / 100.0
    }
    
    mutating func convertToPound(_ amount: Double) -> Double {
        //Pound U.K. 0.83036
        let poundRate : Double = 0.83036
        let pound = amount * poundRate
        return round(100.0 * pound) / 100.0
    }
    
    
    
}
