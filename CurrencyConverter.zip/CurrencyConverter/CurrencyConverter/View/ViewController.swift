//
//  ViewController.swift
//  CurrencyConverter
//
//  Created by Meagan Williams on 2/18/23.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var amountEntered: UITextField!
    @IBOutlet weak var euroSwitch: UISwitch!
    @IBOutlet weak var yenSwitch: UISwitch!
    @IBOutlet weak var pesoSwitch: UISwitch!
    @IBOutlet weak var poundSwitch: UISwitch!
    
    //Variables for Currency
    var usd : Double = 0
    var euro : Double = 0
    var yen : Double = 0
    var peso : Double = 0
    var pound : Double = 0
    var converter = ConverterLogic()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        amountEntered.keyboardType = .numberPad
        amountEntered.delegate = self
    }
    
    //Convert Button Action
    
    @IBAction func convertAction(_ sender: Any) {
        let dollarInput : Double  = Double(amountEntered.text ?? "0") ?? 0
        
        usd = dollarInput
        
        euro = euroSwitch.isOn ? converter.convertToEuro(dollarInput) : -1
        
        yen = yenSwitch.isOn ? converter.convertToYen(dollarInput) : -1
        
        peso = pesoSwitch.isOn ? converter.convertToPeso(dollarInput) : -1
        
        pound = poundSwitch.isOn ? converter.convertToPound(dollarInput) : -1
        
        self.performSegue(withIdentifier: "curr", sender: self)
    }
    
    
    //userValidation
    func textField(_ textField: UITextField,
                   shouldChangeCharactersIn range: NSRange,
                   replacementString string: String) -> Bool { let invalidCharacters =
        CharacterSet(charactersIn: "0123456789").inverted
        return (string.rangeOfCharacter(from: invalidCharacters) == nil)
    }
    
    
    
    //sets amount passed in onto next page
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "curr" {
            let navigation = segue.destination as! CurrencyView
            navigation.usd = usd
            navigation.euro = euro
            navigation.yen = yen
            navigation.peso = peso
            navigation.pound = pound
        }
    }
    
    
    
   

    
}

