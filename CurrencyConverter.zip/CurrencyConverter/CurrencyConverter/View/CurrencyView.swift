//
//  CurrencyView.swift
//  CurrencyConverter
//
//  Created by Meagan Williams on 2/18/23.
//

import UIKit

class CurrencyView: UIViewController {
    
    
    @IBOutlet weak var dollarLabel: UILabel!
    @IBOutlet weak var dollarValue: UILabel!
    @IBOutlet weak var euroLabel: UILabel!
    @IBOutlet weak var euroValue: UILabel!
    @IBOutlet weak var yenLabel: UILabel!
    @IBOutlet weak var yenValue: UILabel!
    @IBOutlet weak var pesoLabel: UILabel!
    @IBOutlet weak var pesoValue: UILabel!
    @IBOutlet weak var poundLabel: UILabel!
    @IBOutlet weak var poundValue: UILabel!
    
    
    
    
    //Variables
    var usd : Double = 0
    var euro : Double = 0
    var yen : Double = 0
    var peso : Double = 0
    var pound : Double = 0

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        dollarValue.text = String(format: "%.2f", usd)
        //display amount or hide label
        euroValue.text = euro != -1 ? String(format: "%.2f", euro) : hideValue(euroLabel, euroValue)
        yenValue.text = yen != -1 ? String(format: "%.2f", yen) : hideValue(yenLabel, yenValue)
        pesoValue.text = peso != -1 ? String(format: "%.2f", peso) : hideValue(pesoLabel, pesoValue)
        poundValue.text = pound != -1 ? String(format: "%.2f", pound) : hideValue(poundLabel, poundValue)
    }
    
    
    
    func hideValue(_ currLabel : UILabel, _ currValue : UILabel) -> String {
        currLabel.isHidden = true
        currValue.isHidden = true
        
        return ""
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
